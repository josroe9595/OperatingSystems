Joseph Monroe
Operating Systems
Homework 2
661220872

Must compile with -lm in order for ceil function to work.
Compile with: gcc -Wall hw2.c -lm